"""Ядро бота v2: хранение заявок, проверка данных, адаптеры авиакомпаний."""
import hashlib, json, os, re, sqlite3, threading, time
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(HERE, "v2.db")
KEY_PATH = os.path.join(HERE, ".v2key")

try:
    from cryptography.fernet import Fernet
    _F = None
except Exception:
    Fernet = None
    _F = None

_lock = threading.RLock()


def _init_key():
    global _F
    if Fernet is None:
        return
    if os.path.exists(KEY_PATH):
        k = open(KEY_PATH, "rb").read().strip()
    else:
        k = Fernet.generate_key()
        with open(KEY_PATH, "wb") as f:
            f.write(k)
        os.chmod(KEY_PATH, 0o600)
    _F = Fernet(k)


_init_key()


def enc(s):
    return _F.encrypt(str(s).encode()).decode() if _F else str(s)


def dec(s):
    if not _F:
        return str(s)
    try:
        return _F.decrypt(str(s).encode()).decode()
    except Exception:
        return str(s)


# ------------------------- база -------------------------
def conn():
    c = sqlite3.connect(DB_PATH, timeout=20)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    with _lock, conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(
            chat_id INTEGER PRIMARY KEY, name TEXT, admin INTEGER DEFAULT 0,
            dry INTEGER DEFAULT 1, created TEXT);
        CREATE TABLE IF NOT EXISTS invites(
            code TEXT PRIMARY KEY, uses_left INTEGER, created TEXT);
        CREATE TABLE IF NOT EXISTS apps(
            id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER, airline TEXT, url TEXT,
            flight TEXT, flight_prefix TEXT, date TEXT, time TEXT, utc_offset REAL,
            seats TEXT, max_price REAL,
            email TEXT, active INTEGER DEFAULT 1, created TEXT);
        CREATE TABLE IF NOT EXISTS pax(
            id INTEGER PRIMARY KEY AUTOINCREMENT, app_id INTEGER, last_name TEXT, doc_enc TEXT,
            email TEXT, doc_format TEXT, done TEXT, taken TEXT);
        CREATE TABLE IF NOT EXISTS appstate(app_id INTEGER PRIMARY KEY, data TEXT);
        CREATE TABLE IF NOT EXISTS posts(
            id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER, url TEXT, hash TEXT,
            last_status TEXT, checked TEXT);
        """)


def ensure_user(chat_id, name, admin_id=353333464):
    with _lock, conn() as c:
        r = c.execute("SELECT chat_id FROM users WHERE chat_id=?", (chat_id,)).fetchone()
        if not r:
            c.execute("INSERT INTO users(chat_id,name,admin,dry,created) VALUES(?,?,?,?,?)",
                      (chat_id, name, 1 if chat_id == admin_id else 0, 1,
                       datetime.utcnow().strftime("%Y-%m-%d %H:%M")))
    return get_user(chat_id)


def get_user(chat_id):
    with _lock, conn() as c:
        r = c.execute("SELECT * FROM users WHERE chat_id=?", (chat_id,)).fetchone()
    return dict(r) if r else None


def new_invite(uses=3):
    code = hashlib.sha1(os.urandom(16)).hexdigest()[:6].upper()
    with _lock, conn() as c:
        c.execute("INSERT INTO invites(code,uses_left,created) VALUES(?,?,?)",
                  (code, uses, datetime.utcnow().strftime("%Y-%m-%d")))
    return code


def use_invite(code):
    code = (code or "").strip().upper()
    with _lock, conn() as c:
        r = c.execute("SELECT uses_left FROM invites WHERE code=?", (code,)).fetchone()
        if not r or r["uses_left"] <= 0:
            return False
        c.execute("UPDATE invites SET uses_left=uses_left-1 WHERE code=?", (code,))
    return True


def create_app(chat_id, d):
    with _lock, conn() as c:
        cur = c.execute("""INSERT INTO apps(chat_id,airline,url,flight,flight_prefix,date,time,
                           utc_offset,seats,max_price,email,active,created)
                           VALUES(?,?,?,?,?,?,?,?,?,?,?,1,?)""",
                        (chat_id, d["airline"], d.get("url", ""), d["flight"], d.get("prefix", ""),
                         d["date"], d["time"], d["utc_offset"], json.dumps(d["seats"]),
                         d.get("max_price") or 0, d.get("email", ""),
                         datetime.utcnow().strftime("%Y-%m-%d %H:%M")))
        app_id = cur.lastrowid
        for p in d["passengers"]:
            c.execute("""INSERT INTO pax(app_id,last_name,doc_enc,email,doc_format,done,taken)
                         VALUES(?,?,?,?,?,?,?)""",
                      (app_id, p["last_name"], enc(p["doc"]), p.get("email") or d.get("email", ""),
                       p.get("doc_format", ""), "", ""))
    return app_id


def apps_of(chat_id=None, only_active=False):
    q = "SELECT * FROM apps"
    args, cond = [], []
    if chat_id is not None:
        cond.append("chat_id=?")
        args.append(chat_id)
    if only_active:
        cond.append("active=1")
    if cond:
        q += " WHERE " + " AND ".join(cond)
    q += " ORDER BY id"
    with _lock, conn() as c:
        return [dict(r) for r in c.execute(q, args).fetchall()]


def app_by_id(app_id):
    with _lock, conn() as c:
        r = c.execute("SELECT * FROM apps WHERE id=?", (app_id,)).fetchone()
    return dict(r) if r else None


def pax_of(app_id):
    with _lock, conn() as c:
        rows = [dict(r) for r in c.execute("SELECT * FROM pax WHERE app_id=? ORDER BY id", (app_id,)).fetchall()]
    for r in rows:
        r["doc"] = dec(r["doc_enc"])
    return rows


def update_pax(pax_id, **kw):
    if not kw:
        return
    sets = ", ".join(f"{k}=?" for k in kw)
    with _lock, conn() as c:
        c.execute(f"UPDATE pax SET {sets} WHERE id=?", list(kw.values()) + [pax_id])


def delete_app(app_id):
    with _lock, conn() as c:
        c.execute("DELETE FROM pax WHERE app_id=?", (app_id,))
        c.execute("DELETE FROM appstate WHERE app_id=?", (app_id,))
        c.execute("DELETE FROM apps WHERE id=?", (app_id,))


def set_active(app_id, active):
    with _lock, conn() as c:
        c.execute("UPDATE apps SET active=? WHERE id=?", (1 if active else 0, app_id))


def state_of(app_id):
    with _lock, conn() as c:
        r = c.execute("SELECT data FROM appstate WHERE app_id=?", (app_id,)).fetchone()
    try:
        return json.loads(r["data"]) if r else {}
    except Exception:
        return {}


def save_state(app_id, st):
    with _lock, conn() as c:
        c.execute("INSERT INTO appstate(app_id,data) VALUES(?,?) "
                  "ON CONFLICT(app_id) DO UPDATE SET data=excluded.data",
                  (app_id, json.dumps(st, ensure_ascii=False)))


def reset_state(app_id):
    save_state(app_id, {})


# ------------------------- проверка ввода -------------------------
CYR = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя"


def norm_name(s):
    s = (s or "").strip().upper().replace("Ё", "E")
    if not s:
        return None, "фамилия пустая"
    if any(ch in CYR for ch in s.lower()):
        return None, "фамилия должна быть латиницей, как в паспорте"
    if not re.fullmatch(r"[A-Z][A-Z '\-]{0,40}", s):
        return None, "в фамилии допустимы только латинские буквы, пробел, дефис и апостроф"
    return s, ""


def doc_variants(doc):
    """Варианты написания номера документа: как ввели, слитно, серия+пробел+номер."""
    d = (doc or "").strip().upper()
    out = []
    if d:
        out.append(d)
    flat = re.sub(r"[\s\-\.]", "", d)
    if flat and flat not in out:
        out.append(flat)
    alnum = re.sub(r"[^A-Z0-9]", "", d)
    if alnum and alnum not in out:
        out.append(alnum)
    m = re.fullmatch(r"(\d{2})(\d{7})", flat)
    if m:
        spaced = f"{m.group(1)} {m.group(2)}"
        if spaced not in out:
            out.append(spaced)
    return out[:4]


def doc_warnings(doc):
    d = (doc or "").upper()
    w = []
    if "O" in d and any(ch.isdigit() for ch in d):
        w.append("в номере есть буква O рядом с цифрами — возможно, это ноль")
    if "I" in d and any(ch.isdigit() for ch in d):
        w.append("в номере есть буква I рядом с цифрами — возможно, это единица")
    if re.fullmatch(r"\d{10}", re.sub(r"\s", "", d)):
        w.append("похоже на внутренний паспорт РФ (4+6 цифр). Для вылета за границу нужен загранпаспорт")
    return w


def doc_kind(doc):
    d = re.sub(r"[\s\-\.]", "", (doc or "").upper())
    if re.fullmatch(r"\d{2}\d{7}", d):
        return "Загранпаспорт РФ (2+7)"
    if re.fullmatch(r"[A-Z]\d{8}", d):
        return "Паспорт РК (буква + 8 цифр)"
    if re.fullmatch(r"\d{4}\d{6}", d):
        return "Похоже на внутренний паспорт РФ (4+6)"
    return "формат не распознан"


def parse_date(s):
    s = (s or "").strip().replace("/", ".").replace("-", ".")
    m = re.fullmatch(r"(\d{1,2})\.(\d{1,2})\.(\d{4})", s)
    if not m:
        return None, "дата в формате ДД.ММ.ГГГГ, например 05.12.2026"
    try:
        dt = datetime(int(m.group(3)), int(m.group(2)), int(m.group(1)))
    except Exception:
        return None, "такой даты нет"
    return dt, ""


def parse_time(s):
    m = re.fullmatch(r"(\d{1,2})[:\.](\d{2})", (s or "").strip())
    if not m or int(m.group(1)) > 23 or int(m.group(2)) > 59:
        return None, "время в формате ЧЧ:ММ, например 20:10"
    return f"{int(m.group(1)):02d}:{int(m.group(2)):02d}", ""


def parse_flight(s):
    s = (s or "").strip().upper().replace(" ", "")
    if re.fullmatch(r"\d{1,4}", s):
        return "", s, ""
    m = re.fullmatch(r"([A-Z]{2})?(\d{1,4})", s)
    if not m or not m.group(2):
        return None, None, "номер рейса, например DV475 или 475"
    return (m.group(1) or ""), m.group(2), ""


def parse_seats(s):
    items = [x.strip().upper() for x in re.split(r"[,;>\n]+", s or "") if x.strip()]
    if not items:
        return None, "пришлите хотя бы один вариант: 12C, EXIT, 1C, AISLE"
    ok = {"EXIT", "LEGROOM", "ANY", "WINDOW", "AISLE"}
    out = []
    for it in items:
        if it in ok or re.fullmatch(r"\d{1,2}[A-K]", it) or re.fullmatch(r"FRONT:\d{1,2}", it):
            out.append(it)
        else:
            return None, f"не понял вариант «{it}». Можно: 12C, 1A, EXIT, LEGROOM, FRONT:5, WINDOW, AISLE, ANY"
    return out, ""


def parse_price(s):
    s = (s or "").strip().replace(" ", "").replace(",", ".")
    if not s or s in ("0", "-", "нет", "no"):
        return 0.0, ""
    s = re.sub(r"(?i)(₸|тг|kzt|тенге|руб|rub|₽|\$|usd|eur|€)", "", s).strip()
    try:
        v = float(s)
    except Exception:
        return None, "цена числом, например 30000"
    if v < 0:
        return None, "цена не может быть отрицательной"
    return v, ""


def parse_offset(s):
    s = (s or "").strip().replace(" ", "")
    try:
        v = float(s.replace(",", "."))
    except Exception:
        return None
    if -12 <= v <= 14:
        return v
    return None


# ------------------------- время -------------------------
def departure_utc(app):
    dt = datetime.strptime(f'{app["date"]} {app["time"]}', "%d.%m.%Y %H:%M")
    return (dt - timedelta(hours=float(app["utc_offset"] or 0))).replace(tzinfo=timezone.utc)


def open_expected(app, hours_before=48.0):
    return departure_utc(app) - timedelta(hours=hours_before)


def fmt_local(utc_dt, offset):
    return (utc_dt + timedelta(hours=float(offset or 0))).strftime("%d.%m %H:%M")


def city_tz(offset):
    names = {5.0: "Астана", 8.0: "Санья", 3.0: "Москва", 6.0: "Алматы", 2.0: "Калининград"}
    name = names.get(float(offset or 0), "")
    return f" (UTC+{offset:g}{', ' + name if name else ''})"


# ------------------------- самолёт и схема мест -------------------------
AIRCRAFT = {
    ("SCAT", "475"): "Boeing 737 MAX 9",
    ("SCAT", "480"): "Boeing 737 MAX 9",
    ("DV", "475"): "Boeing 737 MAX 9",
    ("DV", "480"): "Boeing 737 MAX 9",
}


def aircraft_hint(prefix, flight):
    model = AIRCRAFT.get((prefix or "", flight)) or AIRCRAFT.get(("SCAT", flight))
    lines = []
    if model:
        lines.append(f"По последним полётам этот рейс выполняет {model}.")
    else:
        lines.append("Модель самолёта по этому рейсу бот не знает: смотрите её на Flightradar24 по номеру рейса.")
    code = f"{(prefix or 'DV').lower()}{flight}"
    lines.append(f"Борт и модель по дням: https://www.flightradar24.com/data/flights/{code}")
    lines.append("Схемы мест: https://www.aerolopa.com/ и https://www.seatmaps.com/ — откройте поиск и введите авиакомпанию и модель.")
    if model:
        lines.append(f"Ищите схему: SCAT / Sunday Airlines, {model}.")
    lines.append("Окончательную схему с номерами мест, ценами и аварийными выходами бот сверит в момент открытия регистрации.")
    return "\n".join(lines)


# ------------------------- схема мест для текста -------------------------
def seatmap_text(seatmap, prio, max_price=0.0):
    from sunday_api import iter_seats
    seats = [s for s in iter_seats(seatmap) if s["available"] and not s["restricted"]]
    if not seats:
        return "Свободных мест по схеме нет."
    rows = {}
    for s in seats:
        rows.setdefault(s["row"], []).append(s)
    lines = ["Свободные места по схеме авиакомпании (живые данные):"]
    for row in sorted(rows)[:25]:
        items = []
        for s in sorted(rows[row], key=lambda x: x["seat"]):
            mark = ""
            if "emergencyexit" in s["props"] or "exit" in s["props"]:
                mark = "⇔"
            elif "extralegroom" in s["props"]:
                mark = "+"
            price = f'{int(s["price"])}₸' if s["price"] else "0"
            if max_price and s["price"] > max_price:
                price += "!"
            items.append(f'{s["seat"]}{mark}({price})')
        lines.append(f"{row:>2}: " + " ".join(items))
    lines.append("⇔ у аварийного выхода, + больше места для ног, ₸ цена, «!» дороже вашего потолка")
    return "\n".join(lines)


def seat_dicts(seatmap):
    from sunday_api import iter_seats
    return [{"seat": s["seat"], "row": s["row"], "price": s["price"], "props": s["props"]}
            for s in iter_seats(seatmap)]


def set_dry(chat_id, dry):
    with _lock, conn() as c:
        c.execute("UPDATE users SET dry=? WHERE chat_id=?", (1 if dry else 0, chat_id))
