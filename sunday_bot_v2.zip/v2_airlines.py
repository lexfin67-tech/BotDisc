"""Адаптеры авиакомпаний: Sunday (полный модуль) и универсальный монитор по ссылке."""
import json, logging, re, time
import requests
from sunday_api import SundayApi, ApiError, parse_status, choose_seat, build_do_change, iter_seats
import v2_core as core

log = logging.getLogger("v2.air")


class Result:
    def __init__(self, status, text, extra=None):
        self.status, self.text, self.extra = status, text, extra or {}

    def __repr__(self):
        return f"Result({self.status})"


class SundayAdapter:
    name = "Sunday Airlines"

    # --- поиск с перебором вариантов номера ---
    def _find(self, api, pax, app):
        done_fmt = (pax.get("doc_format") or "").strip()
        attempts = core.doc_variants(pax["doc"])
        if done_fmt:
            attempts = [done_fmt] + [a for a in attempts if a != done_fmt]
        used, data, err = None, None, None
        for i, v in enumerate(attempts):
            if i:
                time.sleep(4)
            try:
                data = api.find(pax["last_name"], v, app["flight"], app["date"])
                used = v
                break
            except ApiError as e:
                if e.code in ("NO_PASSENGER", "EMPTY", "NOT_FOUND", "NO_DATA"):
                    err = e
                    continue
                raise
        return used, data, err

    def probe(self, app, pax):
        """Пробный запрос: найден ли пассажир и когда откроется регистрация."""
        api = SundayApi()
        api.init()
        used, data, err = self._find(api, pax, app)
        if not data:
            code = err.code if err else "NO_PASSENGER"
            return Result("notfound",
                          f'⏳ Принято. Ответ сайта: пассажир {pax["last_name"]} пока не найден ({code}).\n'
                          f'Проверено вариантов номера: {len(core.doc_variants(pax["doc"]))}. '
                          f'Буду проверять раз в час.')
        st = parse_status(data)
        if used and used != pax["doc"]:
            core.update_pax(pax["id"], doc_format=used)
        line = [f'✅ Принято. Ответ сайта: пассажир {st["passengers"][0]["name"] or pax["last_name"]} найден.']
        if st.get("checked_in"):
            line.append(f'Уже зарегистрирован, место {st["passengers"][0]["seat"] or "?"}.')
        elif st.get("enabled"):
            line.append("🟢 Регистрация уже открыта.")
        else:
            line.append(f'Регистрация пока закрыта, статус {st["webcheckin_status"] or "?"}.')
            if st.get("webcheckin_start"):
                line.append(f'Сайт сообщает начало: {st["webcheckin_start"]}.')
            else:
                exp = core.open_expected(app)
                line.append(f'Расчётное открытие: {core.fmt_local(exp, app["utc_offset"])}'
                            f'{core.city_tz(app["utc_offset"])}, ориентировочно.')
        line.append(f'Номер документа принят в формате: {used}')
        if used and " " not in used and len(re.sub(r"\W", "", used)) == 9:
            line.append("Сработал вариант «слитно».")
        return Result("found", "\n".join(line), {"status": st})

    def check(self, app, pax):
        api = SundayApi()
        api.init()
        used, data, err = self._find(api, pax, app)
        if not data:
            return Result("notfound", "", {"code": err.code if err else "NO_PASSENGER"})
        st = parse_status(data)
        return Result("found", "", {"status": st, "api": api, "data": data})

    def seatmap(self, app, pax, st, api, exclude=()):
        me = None
        for p in st["passengers"]:
            if p["name"].upper().startswith(pax["last_name"].upper()):
                me = p
                break
        me = me or st["passengers"][0]
        api.start_change(st["flight_id"], [me["id"]])
        try:
            api.services()
        except ApiError as e:
            log.warning("services: %s", e)
        return api, me, api.seatmap()

    def grab(self, app, pax, seats, max_price=0.0, dry=True, taken=()):
        r = self.check(app, pax)
        if r.status != "found":
            return Result("notfound", f'❌ {pax["last_name"]}: не найден на сайте ({r.extra.get("code")})')
        st = r.extra["status"]
        if st["checked_in"]:
            return Result("done", f'ℹ️ {pax["last_name"]}: уже зарегистрирован, '
                                 f'место {st["passengers"][0]["seat"] or "?"}')
        if not st["enabled"]:
            return Result("closed", f'⏳ {pax["last_name"]}: найден, регистрация закрыта '
                                    f'({st["webcheckin_status"]})')
        api = r.extra["api"]
        api, me, sm = self.seatmap(app, pax, st, api, exclude=taken)
        seat = choose_seat(sm, seats, exclude=set(taken), passenger_id=me["id"])
        if not seat:
            return Result("nofree", f'⚠️ {pax["last_name"]}: регистрация открыта, но ни одно место '
                                    f'из списка не свободно')
        info = f'{seat["seat"]}, {int(seat["price"])} ₸' + (f' ({", ".join(seat["props"])})' if seat["props"] else "")
        if max_price and seat["price"] > max_price:
            return Result("tooprice",
                          f'⚠️ {pax["last_name"]}: лучшее место {info} дороже вашего потолка '
                          f'{int(max_price)} ₸. Заказ не создавал. Схема:\n' + core.seatmap_text(sm, seats, max_price))
        if dry:
            return Result("dry", f'🧪 ТЕСТ {pax["last_name"]}: взял бы место {info}. Заказ не создан.\n'
                                 + core.seatmap_text(sm, seats, max_price))
        api.update_email(me["id"], me["segments"], pax.get("email") or app["email"])
        ch = api.do_change(build_do_change(me["id"], me["segments"][0], seat))
        order_id = ch.get("order_id") or ""
        if not order_id or seat["price"] <= 0:
            api.rpc("checkin-end-change", {})
            return Result("done", f'✅ {pax["last_name"]}: зарегистрирован, место {info} (без оплаты)')
        pms = api.pay_methods("").get("pay_methods") or []
        pm = next((p for p in pms if "card" in (str(p.get("code", "")) + str(p.get("name", ""))).lower()),
                  pms[0] if pms else None)
        if pm:
            api.set_pay_method(order_id, pm["pay_method_id"])
        url = api.start_payment(order_id).get("redirect_url") or ch.get("redirect_url") or ""
        return Result("pay", f'💳 {pax["last_name"]}: место {info} забронировано, заказ {order_id}.\n'
                             f'ОПЛАТИТЕ сейчас: {url or "ссылка не получена, откройте booking.sundayairlines.kz"}',
                      {"seat": seat["seat"], "order": order_id, "url": url})


class MonitorAdapter:
    """Универсальный режим: по ссылке находит поля формы и отправляет их, следит за изменением ответа."""
    name = "Монитор по ссылке"

    FIELDS = [
        (r'last|surname|family|фамил', "last_name"),
        (r'doc|passport|паспорт|document', "doc"),
        (r'flight|рейс', "flight"),
        (r'date|дата', "date"),
    ]

    def probe(self, app, pax):
        try:
            r = requests.get(app["url"], timeout=25, headers={"User-Agent": "Mozilla/5.0"})
        except Exception as e:
            return Result("error", f'⚠️ Ссылка не открылась: {e}')
        html = r.text or ""
        found = []
        for inp in re.findall(r"<input[^>]+>", html, flags=re.I):
            m = re.search(r'name=["\']([^"\']+)', inp, flags=re.I)
            if m:
                found.append(m.group(1))
        if not found:
            return Result("unknown",
                          f'Страница открылась (код {r.status_code}), но полей формы я не нашёл: '
                          f'возможно, она рисуется скриптами или закрыта защитой. Буду следить за изменениями текста.')
        mapping = []
        for name in found:
            for pat, key in self.FIELDS:
                if re.search(pat, name, flags=re.I):
                    mapping.append((name, key))
                    break
        if not mapping:
            mapping = [(found[0], "last_name")]
        return Result("monitor",
                      "Страница открылась. Нашёл поля: " + ", ".join(found[:8]) + "\n"
                      "Сопоставил: " + ", ".join(f"{n}←{k}" for n, k in mapping) + "\n"
                      "Буду раз в час отправлять форму и сообщать, когда ответ изменится. "
                      "Место выбрать в этом режиме нельзя.", {"mapping": mapping})

    def grab(self, app, pax, seats, max_price=0.0, dry=True, taken=()):
        r = self.probe(app, pax)
        return Result("monitor", r.text)


def adapter_for(app):
    if (app.get("airline") or "").lower().startswith("sunday"):
        return SundayAdapter()
    return MonitorAdapter()
