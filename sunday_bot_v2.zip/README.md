# Sunday check-in bot v2

Файлы:
- bot_v2.py — Telegram-бот: заявки через /new, расписание проверок, выбор места до оплаты
- v2_core.py — база заявок (SQLite), проверка ввода, шифрование номеров документов, время
- v2_airlines.py — адаптер Sunday (полный) и универсальный «Монитор» по ссылке

Установка на vm-nano:
  mkdir -p /opt/sunday_bot/v2
  cp bot_v2.py v2_core.py v2_airlines.py sunday_api.py config.json /opt/sunday_bot/v2/
  chmod 600 /opt/sunday_bot/v2/config.json
  cd /opt/sunday_bot/v2 && python3 -m py_compile bot_v2.py v2_core.py v2_airlines.py
  systemctl enable --now sunday-bot-v2

Зависимости: requests, cryptography (уже установлены). sunday_api.py берётся из v1.
База: v2.db, ключ шифрования: .v2key (права 600, создаётся при первом запуске).
