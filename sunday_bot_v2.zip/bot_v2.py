"""Бот v2: заявки через Telegram, проверка регистрации, выбор места до оплаты.
Запуск: python3 bot_v2.py
"""
import json, logging, os, re, threading, time, traceback
from datetime import datetime, timedelta, timezone
import requests

import v2_core as core
from v2_airlines import adapter_for, SundayAdapter, MonitorAdapter

HERE = os.path.dirname(os.path.abspath(__file__))
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s",
                    handlers=[logging.FileHandler(os.path.join(HERE, "v2.log")), logging.StreamHandler()])
log = logging.getLogger("v2.bot")

CFG = json.load(open(os.path.join(HERE, "config.json"), encoding="utf-8"))
TOKEN = os.environ.get("TG_TOKEN") or CFG["telegram"]["token"]
ADMIN = int(CFG["telegram"].get("admin_id") or CFG["telegram"]["chat_id"])
SLOW = float(CFG.get("slow_interval_sec", 3600))
FAST = float(CFG.get("fast_interval_sec", 120))
FAST_BEFORE = float(CFG.get("fast_minutes_before", 10))
FAST_AFTER = float(CFG.get("fast_hours_after", 6))
OPEN_HOURS = float(CFG.get("open_hours_before", 48))

DIALOG = {}
DIALOG_LOCK = threading.RLock()
RUN_LOCK = threading.RLock()
NEXT_RUN = {}


# ------------------------- Telegram -------------------------
def tg(method, **kw):
    try:
        r = requests.post(f"https://api.telegram.org/bot{TOKEN}/{method}", json=kw, timeout=45)
        return r.json()
    except Exception as e:
        log.error("tg %s: %s", method, e)
        return {}


def send(chat_id, text, kb=None, preview=False):
    log.info("TG>%s %s", chat_id, text.replace("\n", " | ")[:250])
    for i in range(0, len(text), 3900):
        kw = dict(chat_id=chat_id, text=text[i:i + 3900], disable_web_page_preview=not preview)
        if kb and i == 0:
            kw["reply_markup"] = {"inline_keyboard": kb}
        tg("sendMessage", **kw)


def edit(chat_id, message_id, text, kb=None):
    kw = dict(chat_id=chat_id, message_id=message_id, text=text[:3900],
              disable_web_page_preview=True)
    if kb:
        kw["reply_markup"] = {"inline_keyboard": kb}
    tg("editMessageText", **kw)


def btn(text, data):
    return {"text": text, "callback_data": data}


# ------------------------- расписание -------------------------
def interval_for(app):
    st = core.state_of(app["id"])
    t = None
    if st.get("open_utc"):
        try:
            t = datetime.strptime(st["open_utc"][:19], "%d.%m.%Y %H:%M:%S").replace(tzinfo=timezone.utc)
        except Exception:
            try:
                t = datetime.strptime(st["open_utc"][:19], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
            except Exception:
                t = None
    if not t:
        t = core.open_expected(app, OPEN_HOURS)
    now = datetime.now(timezone.utc)
    if t - timedelta(minutes=FAST_BEFORE) <= now <= t + timedelta(hours=FAST_AFTER):
        return FAST
    return SLOW


def flight_label(app):
    pref = (app.get("flight_prefix") or "").strip()
    num = f'{pref}{app["flight"]}' if pref else app["flight"]
    return f'{app["airline"]} {num} {app["date"]} {app["time"]}'


def status_line(app):
    st = core.state_of(app["id"])
    pax = core.pax_of(app["id"])
    done = sum(1 for p in pax if p["done"] in ("pay", "done"))
    exp = core.open_expected(app, OPEN_HOURS)
    if st.get("open_utc"):
        try:
            exp = datetime.strptime(st["open_utc"][:19], "%d.%m.%Y %H:%M:%S").replace(tzinfo=timezone.utc)
        except Exception:
            pass
    parts = [f'#{app["id"]} {flight_label(app)}',
             f'  открытие ~{core.fmt_local(exp, app["utc_offset"])}{core.city_tz(app["utc_offset"])}',
             f'  мест взято: {done} из {len(pax)}',
             f'  последняя проверка: {st.get("last") or "—"}',
             f'  {"ТЕСТ" if app.get("_dry") else "БОЕВОЙ"}']
    if st.get("found"):
        parts.append("  пассажир в системе авиакомпании: найден")
    return "\n".join(parts)


def tick(app, force=False, dry=None):
    """Одна проверка заявки."""
    dry = app.get("_dry") if dry is None else dry
    pax_list = core.pax_of(app["id"])
    if not pax_list:
        return
    adm = adapter_for(app)
    st = core.state_of(app["id"])
    first = pax_list[0]
    try:
        r = adm.check(app, first) if hasattr(adm, "check") else adm.probe(app, first)
    except Exception as e:
        log.error(traceback.format_exc())
        st["last"] = f'{datetime.now(timezone.utc):%d.%m %H:%M}Z ошибка {e}'
        core.save_state(app["id"], st)
        send(app["chat_id"], f'⚠️ {flight_label(app)}: ошибка проверки: {e}\n'
                             f'Проверьте вручную: https://booking.sundayairlines.kz/checkin/')
        return
    if r.status == "found" and r.extra.get("status"):
        s = r.extra["status"]
        if not st.get("found"):
            send(app["chat_id"], f'🔎 {flight_label(app)}: пассажир {first["last_name"]} найден в системе. '
                                 f'Статус: {s["webcheckin_status"]}, открытие: {s["webcheckin_start"] or "?"}')
        st["found"] = True
        if s.get("webcheckin_start_utc"):
            st["open_utc"] = s["webcheckin_start_utc"]
        st["last"] = (f'{datetime.now(timezone.utc):%d.%m %H:%M}Z найден '
                      f'open={s.get("enabled")} {s.get("webcheckin_status","")}')
        core.save_state(app["id"], st)
        if s.get("enabled") or force:
            if not st.get("open"):
                send(app["chat_id"], f'🟢 {flight_label(app)}: регистрация ОТКРЫТА. '
                                     f'Начинаю по {len(pax_list)} пасс.')
            st["open"] = True
            core.save_state(app["id"], st)
            taken = []
            for p in pax_list:
                if p["done"] in ("pay", "done"):
                    taken += json.loads(p["taken"] or "[]")
                    continue
                try:
                    res = adm.grab(app, p, json.loads(app["seats"]), app["max_price"] or 0,
                                   dry=dry, taken=taken)
                except Exception as e:
                    log.error(traceback.format_exc())
                    res = None
                    send(app["chat_id"], f'⚠️ {p["last_name"]}: ошибка {e}. '
                                         f'Ручная регистрация: https://booking.sundayairlines.kz/checkin/')
                if res is not None:
                    send(app["chat_id"], res.text)
                    if res.status in ("pay", "done", "dry"):
                        core.update_pax(p["id"], done=res.status,
                                        taken=json.dumps(json.loads(p["taken"] or "[]") +
                                                         ([res.extra["seat"]] if res.extra.get("seat") else [])))
                        if res.extra.get("seat"):
                            taken.append(res.extra["seat"])
            core.save_state(app["id"], st)
    else:
        st["last"] = f'{datetime.now(timezone.utc):%d.%m %H:%M}Z найдено={r.status} {r.extra.get("code","")}'
        if st.get("found") is None:
            st["found"] = False
        core.save_state(app["id"], st)
        if force:
            send(app["chat_id"], r.text or f'Пассажир пока не найден ({r.extra.get("code")}).')


def scheduler():
    while True:
        try:
            for app in core.apps_of(only_active=True):
                if app["chat_id"]:
                    u = core.get_user(app["chat_id"])
                    app["_dry"] = bool(u and u["dry"])
                dep = core.departure_utc(app)
                now = datetime.now(timezone.utc)
                if now > dep + timedelta(hours=2):
                    continue
                k = app["id"]
                if time.time() >= NEXT_RUN.get(k, 0):
                    with RUN_LOCK:
                        tick(app)
                    NEXT_RUN[k] = time.time() + interval_for(app)
        except Exception:
            log.error(traceback.format_exc())
        time.sleep(5)


# ------------------------- диалог /new -------------------------
STEPS = ["airline", "url", "flight", "date", "time", "offset", "passengers", "seats", "price", "email", "confirm"]


def dlog(chat_id, text, kb=None):
    send(chat_id, text, kb)


def start_new(chat_id):
    with DIALOG_LOCK:
        DIALOG[chat_id] = {"step": "airline", "d": {"passengers": []}}
    dlog(chat_id, "Новая заявка. Выберите авиакомпанию.\n\n"
                  "Если её нет в списке — «Другая»: пришлёте ссылку на страницу онлайн-регистрации.",
         [[btn("Sunday Airlines", "al:sunday")], [btn("Другая — пришлю ссылку", "al:other")]])


def ask(chat_id, step):
    d = DIALOG[chat_id]["d"]
    if step == "url":
        dlog(chat_id, "Пришлите ссылку на страницу онлайн-регистрации (не на главную).\n"
                      "Пример: https://booking.sundayairlines.kz/checkin/")
    elif step == "flight":
        dlog(chat_id, "Номер рейса, например DV475 или 475.")
    elif step == "date":
        dlog(chat_id, "Дата вылета в формате ДД.ММ.ГГГГ, например 05.12.2026.")
    elif step == "time":
        dlog(chat_id, "Время вылета по местному времени аэропорта вылета, ЧЧ:ММ, например 20:10.")
    elif step == "offset":
        dlog(chat_id, "Часовой пояс аэропорта вылета (UTC).", [
            [btn("UTC+5 (Астана)", "of:5")], [btn("UTC+8 (Санья)", "of:8")],
            [btn("UTC+3 (Москва)", "of:3")], [btn("Другой — введу числом", "of:ask")]])
    elif step == "passengers":
        dlog(chat_id, "Пассажиры: по одному на строку, фамилия латиницей и номер документа.\n"
                      "Первым — главный пассажир, его бот проверяет чаще.\n\n"
                      "Пример:\nIVANOV 75 1234567\nIVANOVA 75 1234568")
    elif step == "seats":
        dlog(chat_id, "Приоритет мест через запятую — от лучшего к худшему.\n"
                      "Можно конкретные места (12C, 1A) и категории: EXIT (у аварийного выхода), "
                      "LEGROOM (больше места для ног), FRONT:5 (ряды 1–5), WINDOW (у окна), "
                      "AISLE (у прохода), ANY (любое).\n\n"
                      "Пример: 12C, 12D, EXIT, 1C, FRONT:3, AISLE, ANY")
    elif step == "price":
        dlog(chat_id, "Максимальная цена за одно место в тенге. Если не ограничивать — 0.")
    elif step == "email":
        dlog(chat_id, "Email для оформления заказа и чека.")
    elif step == "confirm":
        dlog(chat_id, summary(chat_id), [[btn("Всё верно", "cf:yes"), btn("Отменить", "cf:no")]])


def summary(chat_id):
    d = DIALOG[chat_id]["d"]
    pax = ", ".join(p["last_name"] for p in d["passengers"])
    return (f'Проверьте заявку:\n'
            f'Авиакомпания: {d.get("airline","?")}\n'
            f'Рейс: {d.get("flight","?")} {d.get("date","?")} {d.get("time","?")}'
            f'{core.city_tz(d.get("utc_offset"))}\n'
            f'Пассажиры: {pax}\n'
            f'Места: {", ".join(d.get("seats") or [])}\n'
            f'Потолок цены: {int(d.get("max_price") or 0)} ₸\n'
            f'Email: {d.get("email","?")}\n\n'
            f'Бот проверит пассажира на сайте и включит мониторинг.')


def handle_text(chat_id, text, user):
    with DIALOG_LOCK:
        ds = DIALOG.get(chat_id)
    t = text.strip()
    if t.startswith("/"):
        return handle_command(chat_id, t, user)
    if not ds:
        dlog(chat_id, "Чтобы создать заявку, отправьте /new.\n/all — мои заявки, /help — подсказка.")
        return
    step = ds["step"]
    d = ds["d"]
    err = None
    if step == "url":
        if not re.match(r"^https?://", t):
            err = "нужна ссылка, начинающаяся с http:// или https://"
        else:
            d["url"], d["airline"] = t, "Другая"
    elif step == "flight":
        pref, num, err = core.parse_flight(t)
        if not err:
            d["flight"], d["prefix"] = num, (pref or "")
    elif step == "date":
        dt, err = core.parse_date(t)
        if dt:
            d["date"] = dt.strftime("%d.%m.%Y")
    elif step == "time":
        v, err = core.parse_time(t)
        if v:
            d["time"] = v
    elif step == "offset":
        v = core.parse_offset(t)
        if v is None:
            err = "часовой пояс числом, например 5 или 8"
        else:
            d["utc_offset"] = v
    elif step == "passengers":
        rows = [r for r in re.split(r"[\n;]+", t) if r.strip()]
        pax = []
        for r in rows:
            toks = r.split()
            name_parts, doc_parts = [], []
            for tok in toks:
                if not doc_parts and not any(ch.isdigit() for ch in tok):
                    name_parts.append(tok)
                else:
                    doc_parts.append(tok)
            if not name_parts or not doc_parts:
                err = f'не разобрал строку «{r.strip()}». Формат: IVANOV 75 1234567'
                break
            name, warn = core.norm_name(" ".join(name_parts))
            if not name:
                err = warn
                break
            doc = " ".join(doc_parts).upper()
            if len(re.sub(r"[^A-Z0-9]", "", doc)) < 5:
                err = f'слишком короткий номер документа: «{doc}»'
                break
            pax.append({"last_name": name, "doc": doc, "doc_format": "",
                        "email": d.get("email", "")})
        if not err:
            d["passengers"] = pax
            notes = []
            for p in pax:
                notes.append(f'{p["last_name"]} {p["doc"]}: {core.doc_kind(p["doc"])}')
                for w in core.doc_warnings(p["doc"]):
                    notes.append(f'  ! {w}')
            dlog(chat_id, "Разобрал:\n" + "\n".join(notes))
    elif step == "seats":
        v, err = core.parse_seats(t)
        if v:
            d["seats"] = v
    elif step == "price":
        v, err = core.parse_price(t)
        if v is not None:
            d["max_price"] = v
    elif step == "email":
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[A-Za-z]{2,}", t):
            err = "проверьте email"
        else:
            d["email"] = t
    else:
        dlog(chat_id, "Отправьте /new, чтобы начать новую заявку.")
        return
    if err:
        dlog(chat_id, f"⚠️ {err}")
        return
    idx = STEPS.index(step)
    nxt = STEPS[idx + 1]
    with DIALOG_LOCK:
        DIALOG[chat_id]["step"] = nxt
    ask(chat_id, nxt)


def save_dialog(chat_id, user):
    with DIALOG_LOCK:
        d = DIALOG.pop(chat_id)["d"]
    if d.get("airline") == "Sunday Airlines":
        d.setdefault("seats", ["ANY"])
    app_id = core.create_app(chat_id, d)
    app = core.app_by_id(app_id)
    app["_dry"] = bool(user["dry"])
    adm = adapter_for(app)
    pax_list = core.pax_of(app_id)
    if not isinstance(adm, MonitorAdapter):
        r = adm.probe(app, pax_list[0])
        send(chat_id, r.text)
    else:
        r = adm.probe(app, pax_list[0])
        send(chat_id, r.text)
    send(chat_id, f'Заявка #{app_id} сохранена. Режим: '
                  f'{"ТЕСТ (места не оплачиваются)" if user["dry"] else "БОЕВОЙ"}.\n'
                  f'Проверять буду раз в час, а за 10 минут до открытия — каждые 2 минуты.\n'
                  f'/all — список заявок, /live — включить боевой режим.')
    send(ADMIN, f'Новая заявка #{app_id} от {chat_id} ({user["name"]}): {flight_label(app)}')


def handle_command(chat_id, t, user):
    cmd = t.split()[0].lower()
    if cmd in ("/start", "/help"):
        send(chat_id, "Бот следит за открытием онлайн-регистрации и занимает место до оплаты.\n\n"
                      "/new — новая заявка\n/all — мои заявки\n/status — состояние сейчас\n"
                      "/check — проверить немедленно\n/live — боевой режим (создавать заказы)\n"
                      "/dry — тестовый режим\n/invite — код приглашения (для админа)\n"
                      "/delete ID — удалить заявку")
    elif cmd == "/new":
        start_new(chat_id)
    elif cmd == "/all":
        apps = core.apps_of(chat_id)
        if not apps:
            send(chat_id, "Заявок нет. /new — создать.")
            return
        for a in apps:
            a["_dry"] = bool(user["dry"])
            send(chat_id, status_line(a), [[btn("Проверить сейчас", f"chk:{a['id']}"),
                                            btn("Схема мест", f"sm:{a['id']}")],
                                           [btn("Удалить", f"del:{a['id']}")]])
    elif cmd == "/status":
        apps = core.apps_of(chat_id, only_active=True)
        send(chat_id, "\n\n".join(status_line(a) for a in apps) or "Активных заявок нет.")
    elif cmd == "/check":
        apps = core.apps_of(chat_id, only_active=True)
        send(chat_id, f'Проверяю {len(apps)} заявок…')
        for a in apps:
            with RUN_LOCK:
                tick(a, force=True)
    elif cmd in ("/live", "/dry"):
        core.set_dry(chat_id, cmd == "/dry")
        send(chat_id, "Режим: БОЕВОЙ — бот создаёт заказы и присылает ссылки на оплату." if cmd == "/live"
             else "Режим: ТЕСТ — показывает, какое место взял бы, заказы не создаёт.")
    elif cmd == "/invite":
        if not user["admin"]:
            send(chat_id, "Только для админа.")
            return
        code = core.new_invite(3)
        send(chat_id, f'Код приглашения: {code} (3 использования).\n'
                      f'Человек отправляет боту: /join {code}')
    elif cmd == "/delete":
        parts = t.split()
        if len(parts) < 2 or not parts[1].isdigit():
            send(chat_id, "Формат: /delete 3")
            return
        a = core.app_by_id(int(parts[1]))
        if not a or a["chat_id"] != chat_id:
            send(chat_id, "Не нашёл такую заявку.")
            return
        core.delete_app(a["id"])
        send(chat_id, f'Заявка #{a["id"]} удалена.')
    elif cmd == "/join":
        parts = t.split()
        if len(parts) < 2:
            send(chat_id, "Формат: /join КОД")
            return
        if core.use_invite(parts[1]):
            send(chat_id, "Добро пожаловать! /new — создать заявку.")
        else:
            send(chat_id, "Код неверный или уже использован.")
    else:
        send(chat_id, "Не знаю такую команду. /help")


def handle_callback(chat_id, data, user, message_id):
    with DIALOG_LOCK:
        ds = DIALOG.get(chat_id)
    if data.startswith("al:"):
        v = data.split(":", 1)[1]
        if not ds:
            start_new(chat_id)
            ds = DIALOG[chat_id]
        if v == "sunday":
            ds["d"]["airline"] = "Sunday Airlines"
            ds["step"] = "flight"
            ask(chat_id, "flight")
        else:
            ds["d"]["airline"] = "Другая"
            ds["step"] = "url"
            ask(chat_id, "url")
    elif data.startswith("of:"):
        v = data.split(":", 1)[1]
        if not ds:
            return
        if v == "ask":
            ask(chat_id, "offset")
        else:
            ds["d"]["utc_offset"] = float(v)
            ds["step"] = "passengers"
            ask(chat_id, "passengers")
    elif data.startswith("cf:"):
        v = data.split(":", 1)[1]
        if v == "yes":
            save_dialog(chat_id, user)
        else:
            with DIALOG_LOCK:
                DIALOG.pop(chat_id, None)
            send(chat_id, "Заявка отменена.")
    elif data.startswith("chk:"):
        a = core.app_by_id(int(data.split(":")[1]))
        if a and (a["chat_id"] == chat_id or user["admin"]):
            a["_dry"] = bool(user["dry"])
            send(chat_id, "Проверяю…")
            with RUN_LOCK:
                tick(a, force=True)
    elif data.startswith("sm:"):
        a = core.app_by_id(int(data.split(":")[1]))
        if not a or (a["chat_id"] != chat_id and not user["admin"]):
            return
        adm = adapter_for(a)
        pax = core.pax_of(a["id"])[0]
        try:
            if isinstance(adm, SundayAdapter):
                r = adm.check(a, pax)
                if r.status != "found":
                    send(chat_id, "Пассажир пока не найден на сайте, схема недоступна.")
                    return
                st = r.extra["status"]
                if not st["enabled"]:
                    send(chat_id, f'Схема откроется вместе с регистрацией '
                                  f'(~{core.fmt_local(core.open_expected(a, OPEN_HOURS), a["utc_offset"])}'
                                  f'{core.city_tz(a["utc_offset"])}).\n\n'
                                  + core.aircraft_hint(a.get("flight_prefix"), a["flight"]))
                    return
                api, me, sm = adm.seatmap(a, pax, st, r.extra["api"])
                send(chat_id, core.aircraft_hint(a.get("flight_prefix"), a["flight"]) + "\n\n"
                              + core.seatmap_text(sm, json.loads(a["seats"]), a["max_price"] or 0))
            else:
                send(chat_id, core.aircraft_hint(None, a["flight"]))
        except Exception as e:
            send(chat_id, f'Не получилось: {e}')
    elif data.startswith("del:"):
        a = core.app_by_id(int(data.split(":")[1]))
        if a and a["chat_id"] == chat_id:
            core.delete_app(a["id"])
            edit(chat_id, message_id, f'Заявка #{a["id"]} удалена.')


def commands():
    off = 0
    while True:
        r = tg("getUpdates", offset=off, timeout=30)
        for u in r.get("result", []):
            off = u["update_id"] + 1
            m = u.get("message") or u.get("edited_message") or {}
            c = u.get("callback_query") or {}
            if c:
                chat_id = c["message"]["chat"]["id"]
                data = c.get("data", "")
                name = f'{c["from"].get("first_name","")} {c["from"].get("username","")}'.strip()
                user = core.ensure_user(chat_id, name, ADMIN)
                try:
                    handle_callback(chat_id, data, user, c["message"]["message_id"])
                except Exception:
                    log.error(traceback.format_exc())
                    send(chat_id, "Ошибка обработки кнопки, попробуйте ещё раз.")
                tg("answerCallbackQuery", callback_query_id=c["id"])
                continue
            if not m:
                continue
            chat_id = m["chat"]["id"]
            name = f'{m["from"].get("first_name","")} {m["from"].get("username","")}'.strip()
            txt = (m.get("text") or "").strip()
            user = core.ensure_user(chat_id, name, ADMIN)
            if not txt:
                send(chat_id, "Пришлите текст или /help")
                continue
            try:
                handle_text(chat_id, txt, user)
            except Exception:
                log.error(traceback.format_exc())
                send(chat_id, "Ошибка. Попробуйте ещё раз или /new")
        time.sleep(1)


if __name__ == "__main__":
    core.init_db()
    core.ensure_user(ADMIN, "admin", ADMIN)
    send(ADMIN, "🤖 Бот v2 запущен.\n/new — новая заявка, /all — заявки, /help — подсказка.")
    threading.Thread(target=commands, daemon=True).start()
    scheduler()
